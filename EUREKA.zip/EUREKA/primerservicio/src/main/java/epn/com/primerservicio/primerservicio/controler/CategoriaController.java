/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.com.primerservicio.primerservicio.controler;

/**
 *
 * @author ricardo
 */

import epn.com.primerservicio.primerservicio.exception.ProductoNotFoundException;
import epn.com.primerservicio.primerservicio.modelo.Categoria;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/categorias")
public class CategoriaController {

    private final List<Categoria> lstCategoria  = new ArrayList<>();
    
    @PostMapping("/guardar")
    public String guardarCategoria(@RequestBody List<Categoria> categorias) {
        lstCategoria.clear();
        lstCategoria.addAll(categorias);
        return "Se guardaron " + categorias.size() + " categorias.";
    }

    @GetMapping("/{id}")
    public EntityModel<Categoria> getCategorias(@PathVariable Long id) {
        Categoria p = lstCategoria.stream()
                .filter(cat -> cat.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new ProductoNotFoundException("Categoria",id)); // Lanza excepción si no existe

        return EntityModel.of(p,
                linkTo(methodOn(CategoriaController.class).getCategorias(id)).withSelfRel(),
                linkTo(methodOn(CategoriaController.class).getAll()).withRel("todos"));
    }

    @GetMapping
    public CollectionModel<EntityModel<Categoria>> getAll() {
        List<EntityModel<Categoria>> productos = lstCategoria.stream()
                .map(prod -> EntityModel.of(prod,
                        linkTo(methodOn(CategoriaController.class).getCategorias(prod.getId())).withSelfRel()))
                .toList();
        
        return CollectionModel.of(productos,
                linkTo(methodOn(CategoriaController.class).getAll()).withSelfRel());
    }
    
    @DeleteMapping("/eliminar/{id}")
    public String eliminarCategoria(@PathVariable Long id) {
        boolean eliminado = lstCategoria.removeIf(var -> Objects.equals(var.getId(), id));
        if (eliminado) {
            return "Categoría eliminada con ID: " + id;    
        }
        
        throw new ProductoNotFoundException("Categoria",id);
    }

}

