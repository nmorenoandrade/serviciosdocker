/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.com.primerservicio.primerservicio.modelo;

import lombok.Data;

/**
 *
 * @author ricardo
 */

@Data
public class Empresa {
    private Long id;
    private Long idCategoria;  
    private String ruc;  
    private String descripcion;  

    public Empresa(Long id,Long idCategoria,String ruc, String descripcion) {
        this.id = id;
        this.idCategoria = idCategoria;
        this.ruc = ruc;
        this.descripcion = descripcion;
    }
}
