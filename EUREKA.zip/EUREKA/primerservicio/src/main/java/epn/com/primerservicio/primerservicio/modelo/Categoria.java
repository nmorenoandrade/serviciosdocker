/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.com.primerservicio.primerservicio.modelo;

import lombok.Data;

/**
 *
 * @author ricardo
 */

@Data
public class Categoria {
    private Long id;
    private String descripcion;    

    public Categoria(Long id, String descripcion) {
        this.id = id;
        this.descripcion = descripcion;       
    }
}
