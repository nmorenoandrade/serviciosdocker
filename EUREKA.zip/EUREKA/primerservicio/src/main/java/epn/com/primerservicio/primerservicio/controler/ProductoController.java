/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.com.primerservicio.primerservicio.controler;

/**
 *
 * @author ricardo
 */

import epn.com.primerservicio.primerservicio.exception.ProductoNotFoundException;
import epn.com.primerservicio.primerservicio.modelo.Producto;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    private List<Producto> lista = Arrays.asList(
            new Producto(1L, "Laptop", 850.00),
            new Producto(2L, "Mouse", 25.50)
    );

    @GetMapping("/{id}")
    public EntityModel<Producto> getProducto(@PathVariable Long id) {
        Producto p = lista.stream()
                .filter(prod -> prod.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new ProductoNotFoundException("Producto",id)); // Lanza excepción si no existe

        return EntityModel.of(p,
                linkTo(methodOn(ProductoController.class).getProducto(id)).withSelfRel(),
                linkTo(methodOn(ProductoController.class).getAll()).withRel("todos"));
    }

    @GetMapping
    public CollectionModel<EntityModel<Producto>> getAll() {
        List<EntityModel<Producto>> productos = lista.stream()
                .map(prod -> EntityModel.of(prod,
                        linkTo(methodOn(ProductoController.class).getProducto(prod.getId())).withSelfRel()))
                .toList();
        
        return CollectionModel.of(productos,
                linkTo(methodOn(ProductoController.class).getAll()).withSelfRel());
    }
}

