/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.com.primerservicio.primerservicio.controler;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author CEC
 */
@RestController()
@RequestMapping("/api/v2/persona")
public class Persona {
    // Lista en memoria para almacenar los nombres
    private final List<String> nombresGuardados = new ArrayList<>();

    
   // GET: devolver nombres
    @Operation(
            summary = "Obtiene una lista de nombres",
            description = "Obtiene una lista de nombres que fueron guardados en memoria"
    )
    @ApiResponse(responseCode = "200", description = "No existe Bienvenida")
    @ApiResponse(responseCode = "404", description = "No existe Bienvenida")
    @GetMapping("/listar")
    public List<String> listarNombres() {
        return nombresGuardados;
    }  
    
    @PostMapping("/guarda")
    public String guardarNombres(@RequestBody List<String> nombres) {
        nombresGuardados.clear();
        nombresGuardados.addAll(nombres);
        return "Se guardaron " + nombres.size() + " nombres.";
    }


    
}
