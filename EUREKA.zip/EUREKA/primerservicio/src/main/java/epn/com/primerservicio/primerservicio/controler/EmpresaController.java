/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.com.primerservicio.primerservicio.controler;

/**
 *
 * @author ricardo
 */

import epn.com.primerservicio.primerservicio.exception.ProductoNotFoundException;
import epn.com.primerservicio.primerservicio.modelo.Empresa;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/empresas")
public class EmpresaController {

    private final List<Empresa> lstEmpresa  = new ArrayList<>();
    
    @PostMapping("/guardar")
    public String guardarEmpresa(@RequestBody List<Empresa> categorias) {
        lstEmpresa.clear();
        lstEmpresa.addAll(categorias);
        return "Se guardaron " + categorias.size() + " empresas.";
    }

    @GetMapping("/{id}")
    public EntityModel<Empresa> getEmpresas(@PathVariable Long id) {
        Empresa p = lstEmpresa.stream()
                .filter(cat -> cat.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new ProductoNotFoundException("Empresa",id)); // Lanza excepción si no existe

        return EntityModel.of(p,
                linkTo(methodOn(EmpresaController.class).getEmpresas(id)).withSelfRel(),
                linkTo(methodOn(EmpresaController.class).getAll()).withRel("todos"));
    }

    @GetMapping
    public CollectionModel<EntityModel<Empresa>> getAll() {
        List<EntityModel<Empresa>> productos = lstEmpresa.stream()
                .map(prod -> EntityModel.of(prod,
                        linkTo(methodOn(EmpresaController.class).getEmpresas(prod.getId())).withSelfRel()))
                .toList();
        
        return CollectionModel.of(productos,
                linkTo(methodOn(EmpresaController.class).getAll()).withSelfRel());
    }
    
    @DeleteMapping("/eliminar/{id}")
    public String eliminarEmpresa(@PathVariable Long id) {
        boolean eliminado = lstEmpresa.removeIf(var -> Objects.equals(var.getId(), id));
        if (eliminado) {
            return "Categoría eliminada con ID: " + id;    
        }
        
        throw new ProductoNotFoundException("Empresa",id);
    }

}

