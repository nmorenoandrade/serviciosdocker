/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.com.primerservicio.primerservicio.exception;

/**
 *
 * @author ricardo
 */
public class ProductoNotFoundException extends RuntimeException {
    public ProductoNotFoundException(String dato, Long id) {
        super(dato + " con id " + id + " no encontrado");
    }
}