/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.edu.ec.controler;

/**
 *
 * @author ricardo
 */


import epn.edu.ec.dto.EmpresaDTO;
import epn.edu.ec.exception.CustomException;
import epn.edu.ec.modelo.Empresa;
import epn.edu.ec.servicio.EmpresaService;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.data.domain.Page;

@RestController
@RequestMapping("/empresas")
public class EmpresaController {

    @Autowired
    private EmpresaService empresaService;
   
    @GetMapping("/todo")
    public CollectionModel<EntityModel<EmpresaDTO>> getAll() {
        List<EmpresaDTO> empresas = empresaService.listarEmpresas();

        if (empresas.isEmpty()) {
            throw new CustomException("No hay empresas registradas");
        }

        List<EntityModel<EmpresaDTO>> empresaModels = empresas.stream()
                .map(emp -> EntityModel.of(emp,
                linkTo(methodOn(EmpresaController.class).getAll()).withSelfRel()))
                .toList();

        return CollectionModel.of(empresaModels,
                linkTo(methodOn(EmpresaController.class).getAll()).withSelfRel());

    }
    
    @PostMapping("/guardar")
    public ResponseEntity<String> guardarEmpresa(@RequestBody Empresa empresa) {
  if (empresaService.empresaExistePorRuc(empresa.getRuc())) {
        throw new CustomException("La empresa con RUC " + empresa.getRuc() + " ya existe");
    }

    empresaService.guardarEmpresa(empresa);
    return ResponseEntity.status(HttpStatus.CREATED).body("Empresa guardada correctamente");

    }
    
     @GetMapping("/paginados")
    public ResponseEntity<Page<Empresa>> obtenerEmpresasPaginadas(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "2") int size) {

        Page<Empresa> usuarios = empresaService.listarEmpresasPaginadas(page, size);
        return ResponseEntity.ok(usuarios);
    }

}

