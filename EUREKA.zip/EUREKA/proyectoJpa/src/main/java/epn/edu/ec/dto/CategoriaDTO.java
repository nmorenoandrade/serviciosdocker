/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.edu.ec.dto;

import lombok.Data;

/**
 *
 * @author CEC
 */
@Data
public class CategoriaDTO  {


    private String categoria;

    public CategoriaDTO(String categoria) {
        this.categoria = categoria;
    }

    
}
