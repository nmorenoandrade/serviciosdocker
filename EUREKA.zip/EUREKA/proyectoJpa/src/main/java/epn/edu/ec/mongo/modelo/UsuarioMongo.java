/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.edu.ec.mongo.modelo;

import jakarta.persistence.Id;
import java.util.Map;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;
/**
 *
 * @author ricardo
 */
@Document(collection = "usuarios_mongo")
@Data
public class UsuarioMongo {
    @Id
    private String id;
    private String nombre;
    private String email;
    private Map<String, Object> metadata; // datos semi-estructurados

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
}
