/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.edu.ec.mongo.repository;


import epn.edu.ec.mongo.modelo.UsuarioMongo;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;
/**
 *
 * @author ricardo
 */
public interface UsuarioMongoRepository extends MongoRepository<UsuarioMongo, String> {
    Optional<UsuarioMongo> findByEmail(String email);
}

