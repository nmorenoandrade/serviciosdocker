/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.edu.ec.mongo.mapper;


import epn.edu.ec.mongo.dto.UsuarioDTO;
import epn.edu.ec.mongo.modelo.UsuarioMongo;
import org.mapstruct.Mapper;
/**
 *
 * @author ricardo
 */
@Mapper(componentModel = "spring")
public interface UsuarioMapper {
   // UsuarioDTO toDto(UsuarioSQL sqlEntity);
    UsuarioDTO toDto(UsuarioMongo mongoEntity);
   // UsuarioSQL toSqlEntity(UsuarioDTO dto);*/
    UsuarioMongo toMongoEntity(UsuarioDTO dto);
}
