/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.edu.ec.servicio;


import epn.edu.ec.modelo.Ventas;
import epn.edu.ec.repository.VentasRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author CEC
 */
@Service
public class VentasService {

    @Autowired
    private VentasRepository repository;

    public Ventas guardarVenta(Ventas usuario) {
        return repository.save(usuario);
    }

    public List<Ventas> listarVentas() {
        return repository.findAll();
    }    

}
