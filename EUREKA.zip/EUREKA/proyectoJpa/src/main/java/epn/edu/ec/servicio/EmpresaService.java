/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.edu.ec.servicio;

import epn.edu.ec.dto.EmpresaDTO;
import epn.edu.ec.modelo.Empresa;
import epn.edu.ec.repository.EmpresaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

/**
 *
 * @author CEC
 */
@Service
public class EmpresaService {

    @Autowired
    private EmpresaRepository repository;

    public Empresa guardarEmpresa(Empresa usuario) {
        return repository.save(usuario);
    }
public boolean empresaExistePorRuc(String ruc) {
    return repository.existsByRuc(ruc);
}

    public List<Empresa> listarEmpresa() {
        return repository.findAll();
    }   
    
    
    
  public List<EmpresaDTO> listarEmpresas() {
    return repository.findAll().stream()
        .map(e -> new EmpresaDTO(e.getId(), e.getNombre(), e.getTelefono(), e.getRuc(), e.getIdTipo()))
        .collect(Collectors.toList());
}
  
 public Page<Empresa> listarEmpresasPaginadas(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("nombre").ascending());
        return repository.findAll(pageable);
    }
 

}
