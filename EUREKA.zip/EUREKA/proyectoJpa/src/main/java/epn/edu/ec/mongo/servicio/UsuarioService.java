/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.edu.ec.mongo.servicio;


import epn.edu.ec.mongo.dto.UsuarioDTO;
import epn.edu.ec.mongo.mapper.UsuarioMapper;
import epn.edu.ec.mongo.modelo.UsuarioMongo;
import epn.edu.ec.mongo.repository.UsuarioMongoRepository;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author ricardo
 */
@Service
public class UsuarioService {

   

    @Autowired
    private UsuarioMongoRepository mongoRepo;

    @Autowired
    private UsuarioMapper mapper;

   
    // Guardar en MongoDB
    public UsuarioDTO guardarMongo(UsuarioDTO dto) {
        UsuarioMongo entity = mapper.toMongoEntity(dto);
        mongoRepo.save(entity);
        return mapper.toDto(entity);
    }

   

    // Listar usuarios de MongoDB
    public List<UsuarioDTO> listarMongo() {
        return mongoRepo.findAll()
                .stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());
    }
}