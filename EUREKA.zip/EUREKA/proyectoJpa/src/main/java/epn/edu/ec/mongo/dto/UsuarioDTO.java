/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.edu.ec.mongo.dto;

import java.util.Map;
import lombok.Data;

/**
 *
 * @author ricardo
 */
@Data
public class UsuarioDTO {
    private String id;
    private String nombre;
    private String email;
    private Map<String, Object> metadata;

    public UsuarioDTO(String id, String nombre, String email, Map<String, Object> metadata) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.metadata = metadata;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
}
