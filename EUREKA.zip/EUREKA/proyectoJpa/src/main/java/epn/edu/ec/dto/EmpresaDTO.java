/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.edu.ec.dto;

import lombok.Data;

/**
 *
 * @author CEC
 */
@Data
public class EmpresaDTO  {

    private String nombre;
    private String telefono; 
    private String ruc; 
    private Integer idTipo;

    public EmpresaDTO(String nombre, String telefono, String ruc, Integer idTipo) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.ruc = ruc;
        this.idTipo = idTipo;
    }

    public EmpresaDTO(Long id, String nombre, String telefono, String ruc, Integer idTipo) {
         this.nombre = nombre;
        this.telefono = telefono;
        this.ruc = ruc;
        this.idTipo = idTipo;
    }
      
}
