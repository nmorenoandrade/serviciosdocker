/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package epn.edu.ec.exception;

/**
 *
 * @author ricardo
 */
public class CustomException extends RuntimeException {
    public CustomException(String mensaje) {
        super(mensaje);
    }
}