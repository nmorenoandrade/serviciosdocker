package epn.edu.ec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoJpaApplicationTests {

    @Test
    void contextLoads() {
    }
}

